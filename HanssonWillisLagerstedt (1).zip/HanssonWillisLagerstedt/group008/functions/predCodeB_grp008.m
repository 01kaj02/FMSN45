%% Stand-alone predictor part B
% Kajsa Hansson Willis & Victoria Lagerstedt 
% Tidsserieanalys HT24 

% This is the stand-alone predictor for part B of the project. 
% The full data set of the input data should be inserted into the inputData and the outputData
% should include the entire data set of the temperature, including the test data. The
% testDataInd should be the index of the test data that should be
% predicted. The kStep should be the prediction horizon. 

function predValues = predCodeB_grp008( inputData, outputData, testDataInd, kStep)

% Check so that no input is provided for part A.
if testDataInd(end) > length(outputData)
    error('The test data is past the output data set.')
end

% Ensure that the input and the output are equally long so that vector
% operations can be done
if length(outputData) > length(inputData)
    outputData = outputData(1:length(inputData));
elseif length(inputData) > length(outputData)
        inputData = inputData(1:length(outputData));
end

k = kStep;


% Input model
A_test = [1 0.05284 -0.1012 0.2068 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5606];
C_test = [1 0.8191 0.5513 0.5943 0.4171 0.2914 0.2071 0.1534 0.1111 0.0381]; 


% Add the differentiation to the model
A_test = conv([1 zeros(1, 23) -1 ], A_test); 

% Create the input prediction 
[~, G] = polydivision(C_test, A_test, k);
xhatk = filter(G, C_test, inputData); 


% Output model parameters
B = [0.0062    0.0042    0.0018    0.0010];
C1 = [1.0000   -1.6979    1.3463   -1.3335    1.1785   -0.1203   -0.3175    0.1102 -0.1688    0.0748   -0.1028    0.1213   -0.1267    0.1316   -0.1172    0.0218  0.0567   -0.0574    0.0913   -0.0967    0.0496   -0.0033    0.0652   -0.0366];
A1 = [1.0000   -3.0563    4.0857   -3.9310    3.6920   -2.5542    0.7638];
A2 = [1]; % F
KA = conv(A1, A2); %A1*A2
KB = conv(A1, B); %A1*B
KC = conv(A2, C1); %A2*C1

% The prediction 
[Fy, Gy] = polydivision( C1, A1, k);
[Fhh, Ghh] = polydivision(conv(Fy,KB), KC, k);
yhatk = filter(Fhh,1,xhatk) + filter(Ghh,KC,inputData) + filter(Gy, KC, outputData); 

% Limiting it to the test data set
yhatk = yhatk(testDataInd); 
predValues = yhatk; 

end 
