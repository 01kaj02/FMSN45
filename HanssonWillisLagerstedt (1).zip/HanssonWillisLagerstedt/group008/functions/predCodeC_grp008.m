%% Stand-alone predictor part C
% Kajsa Hansson Willis & Victoria Lagerstedt 
% Tidsserieanalys HT24 

% This is the stand-alone predictor for part C of the project. 
% The full data set of the input data should be inserted into the inputData and the outputData
% should include the entire data set of the temperature, including the test data. The
% testDataInd should be the index of the test data that should be
% predicted. The kStep should be the prediction horizon. 

function predValues = predCodeC_grp008( inputData, outputData, testDataInd, kStep)

% Check so that the testDataInd is not outside the outputData 
if testDataInd(end) > length(outputData)
    error('The test data is past the output data set.')
end

% Ensure that the input and the output are equally long so that vector
% operations can be done
if length(outputData) > length(inputData)
    outputData = outputData(1:length(inputData));
elseif length(inputData) > length(outputData)
        inputData = inputData(1:length(outputData));
end


k = kStep;


N = testDataInd(1)-1; % The modeling data
T = length(testDataInd); % The test data
N = length(inputData);

xy = inputData;
p0 = 9;                                         
q0 = 8;


% Initialization 
% Coefficients for the ARMApolynomials in B (but skipping zeroes) 
initialVector = [0.0528397490288375	-0.101196205995669	0.206840167376422	-0.439378863960735	-0.0528397490288375	0.101196205995669	-0.206840167376422	-0.560621136039265 0.819084877316341	0.551287933376244	0.594313277080926	0.417096943364277	0.291422787928789	0.207143001159529	0.153405795663104	0.111067306439079	0.0381049043925346];

A     = eye(p0+q0); 
Rw    = 2;                                    
Re    = 0.00000001*eye(p0+q0);                
Rx_t1 = 4*eye(p0+q0);  
h_et  = zeros(N+T,1);                             
xt    = ones(p0+q0,N+T-k);                       
xt    = xt.*initialVector';                       
yhat  = zeros(N+T-k,1);                           
xyhatK = zeros(1,N+k+T); 
xStd  = zeros(p0+q0,N+T-k);                       
xStdk = zeros(p0+q0,N+T-k);                       


for t=49:N-49 
    x_t1 = A*xt(:,t-1);                      
    C  = [ -xy(t-1) -xy(t-2) -xy(t-3) -xy(t-24) -xy(t-25) -xy(t-26) -xy(t-27) -xy(t-48) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8) h_et(t-9)];  
    
    Ry = C*Rx_t1*C' + Rw;                      
    Kt = Rx_t1*C'/Ry;                         
    yhat(t) = C*x_t1;                       
    h_et(t) = xy(t)-yhat(t);                   
    xt(:,t) = x_t1 + Kt*(h_et(t));           

    Rx_t  = Rx_t1 - Kt*Ry*Kt';               
    Rx_t1 = A*Rx_t*A' + Re;                     

    % K = 1
    Ck = [ -xy(t) -xy(t-1) -xy(t-2) -xy(t-23) -xy(t-24) -xy(t-25) -xy(t-26) -xy(t-47) h_et(t) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8)];         
    yk = Ck*A*xt(:,t);                 
    
    Rx_k = Rx_t1;

    for k0=2:k 
        if k == 2
            Ck  = [ -xyhatK(t-1+k0) -xy(t-2+k0) -xy(t-3+k0) -xy(t-24+k0) -xy(t-25+k0) -xy(t-26+k0) -xy(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 3
            Ck  = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xy(t-3+k0) -xy(t-24+k0) -xy(t-25+k0) -xy(t-26+k0) -xy(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 25
            Ck = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xyhatK(t-3+k0) -xy(t-24+k0) -xy(t-25+k0) -xy(t-26+k0) -xy(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 26
            Ck  = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xyhatK(t-3+k0) -xyhatK(t-24+k0) -xy(t-25+k0) -xy(t-26+k0) -xy(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 27
            Ck  = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xyhatK(t-3+k0) -xyhatK(t-24+k0) -xyhatK(t-25+k0) -xy(t-26+k0) -xy(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 28
            Ck  = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xyhatK(t-3+k0) -xyhatK(t-24+k0) -xyhatK(t-25+k0) -xyhatK(t-26+k0) -xy(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 49
            Ck  = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xyhatK(t-3+k0) -xyhatK(t-24+k0) -xyhatK(t-25+k0) -xyhatK(t-26+k0) -xyhatK(t-27+k0) -xy(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        else
            Ck = [ -xyhatK(t-1+k0) -xyhatK(t-2+k0) -xyhatK(t-3+k0) -xyhatK(t-24+k0) -xyhatK(t-25+k0) -xyhatK(t-26+k0) -xyhatK(t-27+k0) -xyhatK(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0)]; % C|t-1    
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        end
    end 

    xyhatK(t+k) = yk;                             

    % Standard deviations 
    xStd(:,t) = sqrt(diag(Rx_t) );             
    xStdk(:,t) = sqrt(diag(Rx_k) );            
end



xhatk = xyhatK;

% Setting up the output model 
foundModelD = [1.0000   -1.7993    0.3148    0.6121    0.9218   -1.5894    0.5402];
foundModelF = [1];
foundModelB = [0.0068    0.0046    0.0019    0.0010];
foundModelC = [1.0000   -0.6167   -0.5515   -0.0533    0.9099   -0.2689    0.0429   -0.0180  -0.2438    0.1044   -0.0110    0.0205   -0.0774    0.0119    0.0351   -0.0013 0.0038   -0.2115    0.1116    0.0620    0.0550   -0.1360    0.0911   -0.0019];

KA = conv( foundModelD, foundModelF );
KB = conv( foundModelD, foundModelB );
KC = conv( foundModelF, foundModelC );

noPar   = 39;                            
xt      = zeros(noPar,N);               
xt(:,2) = [ KA(2) KA(3) KA(4) KA(5) KA(6) KA(7) KB(1) KB(2) KB(3) KB(4) KB(5) KB(6) KB(7) KB(8) KB(9) KB(10) KC(2) KC(3) KC(4) KC(5) KC(6) KC(7) KC(8) KC(9) KC(10) KC(11) KC(12) KC(13) KC(14) KC(15) KC(16) KC(17) KC(18) KC(19) KC(20) KC(21) KC(22) KC(23) KC(24) ];


% Initialization 
x = inputData;
y = outputData;

A     = eye(noPar); 
Rw    = 1;                              
Re    = 1e-6*eye(noPar);                        
Rx_t1 = 1e-4*eye(noPar);                        
h_et  = zeros(N+T,1); 
yhat  = zeros(N+T-k,1);
yhatK = zeros(1,N+T+k);                         
xStd_  = zeros(noPar,N+T);
xStdk_ = zeros(noPar,N+T);
startInd = 25;


for t=startInd:N-startInd
    x_t1 = A*xt(:,t-1);                         
    C = [ -y(t-1) -y(t-2) -y(t-3) -y(t-4) -y(t-5) -y(t-6) x(t) x(t-1) x(t-2) x(t-3) x(t-4) x(t-5) x(t-6) x(t-7) x(t-8) x(t-9) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8) h_et(t-9) h_et(t-10) h_et(t-11) h_et(t-12) h_et(t-13) h_et(t-14) h_et(t-15) h_et(t-16) h_et(t-17) h_et(t-18) h_et(t-19) h_et(t-20) h_et(t-21) h_et(t-22) h_et(t-23)];
    yhat(t) = C*x_t1;

    Ry = C*Rx_t1*C' + Rw;                       
    Kt = Rx_t1*C'/Ry;                           
    h_et(t) = y(t)-yhat(t);                    
    xt(:,t) = x_t1 + Kt*( h_et(t) );            

    Rx_t  = Rx_t1 - Kt*Ry*Kt';                 
    Rx_t1 = A*Rx_t*A' + Re;                     

 
    %1-step prediction
    C1 = [ -y(t) -y(t-1) -y(t-2) -y(t-3) -y(t-4) -y(t-5) xhatk(t+1) x(t) x(t-1) x(t-2) x(t-3) x(t-4) x(t-5) x(t-6) x(t-7) x(t-8) h_et(t) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8) h_et(t-9) h_et(t-10) h_et(t-11) h_et(t-12) h_et(t-13) h_et(t-14) h_et(t-15) h_et(t-16) h_et(t-17) h_et(t-18) h_et(t-19) h_et(t-20) h_et(t-21) h_et(t-22)];           
    yk = C1*xt(:,t); 
    Rx_k = Rx_t1;

    for k0=2:k 
        if k == 2
            Ck = [ -yhatK(t-1+k0) -y(t-2+k0) -y(t-3+k0) -y(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) x(t-2+k0) x(t-3+k0) x(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 3
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -y(t-3+k0) -y(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) x(t-3+k0) x(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 4
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -y(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) x(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 5
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 6
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 7
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 8
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) xhatk(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 9
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) xhatk(t-7+k0) xhatk(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        else
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) xhatk(t-7+k0) xhatk(t-8+k0) xhatk(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        end
    end 

    yhatK(t+k) = yk;
 
     % Standard deviations 
    xStd_(:,t) = sqrt(diag(Rx_t) );             
    xStdk_(:,t) = sqrt(diag(Rx_k) );   
end


predValues = yhatK(testDataInd)';

end 