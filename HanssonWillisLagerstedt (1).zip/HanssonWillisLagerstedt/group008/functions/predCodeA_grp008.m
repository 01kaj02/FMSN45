%% Stand-alone predictor part A
% Kajsa Hansson Willis & Victoria Lagerstedt 
% Tidsserieanalys HT24 

% This is the stand-alone predictor for part A of the project. 
% An empty vector should be inserted into the inputData and the outputData
% should include the entire data set, including the test data. The
% testDataInd should be the index of the test data that should be
% predicted. The kStep should be the prediction horizon. 

function predValues = predCodeA_grp008( inputData, outputData, testDataInd, kStep)

% Check so that no input is provided for part A.
if ~isempty(inputData)
    error('The predictor for part A does not use any input.')
end

k = kStep;

% The model parameters 
A = [1 -2.9526 2.6310 0 -1.0407 0.3623];
C = [1 -1.5560 -0.0492 0.8044 -0.1043 0 0 -0.0196 -0.0466]; 


% The prediction 
[~, Gk] = polydivision(C, A, k);
yhat_k = filter(Gk, C, outputData); % No length adjustment here as it is done later to only extract the test data


% Limiting it to the test data set
yhat_k = yhat_k(testDataInd); 
predValues = yhat_k;


end 
