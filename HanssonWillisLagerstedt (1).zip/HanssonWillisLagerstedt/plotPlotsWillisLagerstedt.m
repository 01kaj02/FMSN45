function plotPlotsWillisLagerstedt(data)

figure;
subplot (411) 
plot(data) 
title('Signal');
subplot (412) 
a = acf(data,50,0.05,1,0,0);
title('ACF');
subplot (413)
p = pacf(data,50,0.05,1,0);
title('PACF');
subplot (414)
n = normplot(data);
title('Normplot');

