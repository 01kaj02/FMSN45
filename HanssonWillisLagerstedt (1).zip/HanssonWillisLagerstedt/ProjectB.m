%% Project Part B 
% Kajsa Hansson Willis & Victoria Lagerstedt
% Fall 2024 

clear; clc;
close all;

%% Creating subdata and checking them
addpath('data')
addpath('functions')

load 'projectData24.mat'
airTemperature = data(:,[8]);

maxOrd = 50;
N = length(airTemperature);
N_model = 1344; % 8 weeks of data 
T = 3000; % The right placement of the modeling data  

set_temp = airTemperature(T:N_model+T); 

% To choose which input we want to use:
figure;
hold on
subplot(411);
plot(airTemperature);
title('Air temperature');
subplot(412);
plot(data(:,[6]));
title('Radiation data');
subplot(413);
plot(data(:,[5]));
title('Reflected shortwave radiation');
subplot(414);
plot(data(:,[7]));
title('Earth heat flux');
hold off


% Radiation is the choosen input
rad = data(:,[6]);
plotPlotsWillisLagerstedt(rad);

figure;
hold on
subplot(211);
plot(airTemperature);
title('Air temperature');
subplot(212);
plot(rad);
title('Radiation data');
hold off

% Creating the modelling set for input data
set_rad = rad(T:N_model+T);
plotPlotsWillisLagerstedt(set_rad);

% Creating validation data and test data.
rad_val = rad(N_model+T:N_model+T+335); % 336 hours (two weeks) of validation data 
test1rad = rad(N_model+3336-50:N_model+3503);
val = airTemperature(N_model+T:N_model+T+335);
test1 = airTemperature(N_model+T+336-50:N_model+T+503);

%% Examining the input data

% Our data is not normal which might suggest a transformation of the input
% could be beneficial 
figure
[maxLambda] = bcNormPlot(rad,1);

testMean(set_rad) % 1 
min(set_rad); % -96.7
max(set_rad); % 574.4 
mean(set_rad); % 115

disp('Are ACF and PACF normal distributed:');
checkIfNormal( acf(set_rad(2:end), 50), 'ACF' );
checkIfNormal( pacf(set_rad(2:end), 50), 'PACF' );

disp('Is the data normally distributed:');
checkIfNormal(set_rad(2:end), 'Net radiation');

%% Estimating the input

% As a transform creates various problems, it may not always be beneficial
% to do so, so we try creating a model without transformation first, and if
% we are not happy we will go back and transform the data. 

plotPlotsWillisLagerstedt(set_rad); 

% Looks like season so we differentiate it
w = filter([1 zeros(1,23) -1], 1, set_rad); 
w = w(24:end);
plotPlotsWillisLagerstedt(w);

A_test = [1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];
C_test = [1 1 1 1 1 1 1 1 1 1]; 


foundModelB = estimateARMA(w, A_test, C_test, 'Model for input', 30);
% All the coefficients are significant 


% Add the differentiation to the model
foundModelB.A = conv([ 1 zeros(1, 23) -1 ], foundModelB.A);

% Still a peak at 24 but it works! Tried to add a 23 and 25 AR coefficient
% but they were insignificant

%% Prediction of input for data

k = 1;

[F, G] = polydivision( foundModelB.C, foundModelB.A, k );
xhatk = filter(G, foundModelB.C, set_rad );

xhatk = xhatk(length(G):end);

figure
hold on
plot(xhatk);
plot(set_rad(length(G):end));
legend('Prediction', 'Real data');
hold off

ehat = set_rad(length(G):end) - xhatk;
checkIfWhite(ehat);
plotPlotsWillisLagerstedt(ehat);
% It is white 

%% Checking input validation data 

[F, G] = polydivision( foundModelB.C, foundModelB.A, k );
xhatkVal = filter(G, foundModelB.C, rad_val );

xhatkVal = xhatkVal(length(G):end);

testDataIndt = N_model+T:N_model+T+335;

if k == 1
   [xNaiveTest, var_naive_test] = naivePred(rad, testDataIndt, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [xNaiveTest, var_naive_test] = naivePred(rad, testDataIndt, k, 24-k); 
end 


figure
hold on
plot(xhatkVal);
plot(rad_val(length(G):end));
plot(xNaiveTest(length(G):end))
legend('Prediction', 'Real data', 'Naive');
hold off

ehat = rad_val(length(G):end) - xhatkVal;
checkIfWhite(ehat);
plotPlotsWillisLagerstedt(ehat);

var(rad_val)

g = length(G);
fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ehat))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ehat)/var(rad_val(g:end)));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test/var(rad_val(g:end)));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ehat)/var(rad_val(length(G):end)))*100) ;
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test/var(rad_val(length(G):end)))*100 );

plotACFnPACF(ehat, 50, 'ACF & PACF for prediction');


%% Checking input test data

[F, G] = polydivision( foundModelB.C, foundModelB.A, k );
xhatkTest = filter(G, foundModelB.C, test1rad );

xhatkTest = xhatkTest(length(G):end);

testDataIndt = N_model+3336-50:N_model+3503;

if k == 1
   [xNaiveTest1, var_naive_test1] = naivePred(rad, testDataIndt, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [xNaiveTest1, var_naive_test1] = naivePred(rad, testDataIndt, k, 24-k); 
end 

figure
hold on
plot(xhatkTest);
plot(test1rad(length(G):end));
plot(xNaiveTest1(length(G):end))
legend('Prediction', 'Real data', 'Naive');
hold off

ehat = test1rad(length(G):end) - xhatkTest;
checkIfWhite(ehat);
plotPlotsWillisLagerstedt(ehat);

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ehat))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ehat)/var(test1rad(g:end)));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test1 )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test1/var(test1rad(g:end)));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ehat)/var(test1rad(g:end)))*100) 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test1/var(test1rad(g:end)))*100 ) 

%% Forming the filtered signals and observering the cross-correlation

wt = filter(foundModelB.A, foundModelB.C,set_rad);
wt = wt(length(G):end);
eps = filter(foundModelB.A, foundModelB.C,set_temp);
eps = eps(length(G):end);

figure;
M=40;
stem(-M:M, xcorr(eps ,wt, M, 'normalized')); 
title('Cross correlation function epsilon and w'), 
xlabel('Lag')
hold on
plot(-M:M, 2/sqrt(length(eps))*ones(1,2*M+1),'--') 
plot(-M:M, -2/sqrt(length(eps))*ones(1,2*M+1),'--') 
hold off

% Trying with (d,r,s) to be (0,0,4)
% First peak is at zero -> d = 0
% r is zero because it has a finite amount of peaks over the confidence
% interval and then goes to zero at d+s. It has 4 peaks which is why we
% tried with s=4


A2 = [1];
B = [1 1 1 1];
Mi = idpoly ([1] ,[B] ,[] ,[] ,[A2]);
z = iddata(set_temp(48+k:end),xhatk);
Mba2 = pem(z,Mi); 
present(Mba2)
etilde = resid (Mba2, z );

plotPlotsWillisLagerstedt(etilde.y);

%% Checking pole-zero cancellation and cross-correlation 

figure
subplot(411)
zplane( Mba2.C)
title('C polynomial')
subplot(412)
zplane( Mba2.A )
title('A polynomial')
subplot(413)
zplane( foundModelB.C)
title('C polynomial input model')
subplot(414)
zplane( foundModelB.A )
title('A polynomial input model')

% Ensuring no pole-zero cancellation
figure
pzplot(Mba2)
figure
pzplot(foundModelB)

%% Estimating a model for the residual

new_model = estimateARMA(etilde.y, [1 1 0 0 0 0 0 1 zeros(1,13) 0 0 1], [1 1 0 1 0 1 1], 'ARMA model for input', 30);
% White noise

%% Predicting the Box-Jenkins model


A1 = [1 1 0 1 0 1 1];
A2 = [1];
B = [1 1 1 1];
C = [1 1 0 0 0 0 0 1 zeros(1,13) 0 0 1];

Mi = idpoly (1 ,B,C,A1,A2); 
z = iddata(set_temp,set_rad);
MboxJ = pem(z ,Mi); 
present (MboxJ);
ehat = resid(MboxJ,z);

checkIfWhite(ehat.y);

disp('Are ACF and PACF normal distributed:');
checkIfNormal( acf(ehat.y(2:end), 50), 'ACF' );
checkIfNormal( pacf(ehat.y(2:end), 50), 'PACF' );
plotPlotsWillisLagerstedt(ehat.y);
% Not normal distributed so the whiteness tests can not be trusted


% Used to copy into part C
MboxJ.A;
MboxJ.B;
MboxJ.C;
MboxJ.D;
MboxJ.F;

%Check for pole-zero cancellation
figure;
pzplot(MboxJ);


%% Building the prediction

KA = conv(MboxJ.D, MboxJ.F);
KB = conv(MboxJ.D, MboxJ.B);
KC = conv(MboxJ.F, MboxJ.C);

k = 1;

[Fy, Gy] = polydivision( MboxJ.C, MboxJ.D, k);
[Fhh, Ghh] = polydivision(conv(Fy, KB), KC, k);


yhatk2 = filter(Fhh,1,xhatk) + filter(Ghh,KC,set_rad(48+k:end)) + filter(Gy, KC, set_temp(48+k:end));
maxremove = max([length(Fhh), length(Ghh), length(Gy), length(KC), length(Fy), length(KB), length(C)]);
yhatk2 = yhatk2(maxremove:end);


% With the naive predictor  
testDataInd = T:(T+N_model); 
if k == 1
    [naivePredic, var_naive] = naivePred(airTemperature, testDataInd, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [naivePredic, var_naive] = naivePred(airTemperature, testDataInd, k, 24-k); 
end 

figure
plot([set_temp(maxremove+47+k:end) yhatk2]);
hold on
plot(naivePredic(maxremove+47+k:end));
hold off
legend('Real data', 'Model', 'Naive');


ek = set_temp(maxremove+47+k:end) - yhatk2;

checkIfWhite(ek);


fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(set_temp(maxremove+48:end)));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ek));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ek)/var(set_temp(maxremove+48:end)));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive/var(set_temp(maxremove+48:end)));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ek)/var(set_temp(maxremove+48:end)))*100)
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive/var(set_temp(maxremove+48:end)))*100 ); 


%% Validation data
k = 1;

[F, G] = polydivision( foundModelB.C, foundModelB.A, k );
xhatk = filter(G, foundModelB.C, rad_val );

xhatk = xhatk(length(G):end);


yhatval = filter(Fhh,1,xhatk) + filter(Ghh,KC,rad_val(48+k:end)) + filter(Gy, KC,val(48+k:end));

maxremove = max([length(Fhh), length(Ghh), length(Gy), length(KC) length(Fy), length(KB), length(C)]);
yhatval = yhatval(maxremove:end);


ekval = val(maxremove+47+k:end) - yhatval;


% With the naive predictor  
testDataInd1 = N_model+T:N_model+T+335;
if k == 1
    [yNaiveVal, var_naive_val] = naivePred(airTemperature, testDataInd1, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveVal, var_naive_val] = naivePred(airTemperature, testDataInd1, k, 24-k); 
end 


figure
plot([val(maxremove+47+k:end) yhatval yNaiveVal(length(G)+maxremove-1:end)]);
legend('Real data', 'Model', 'Naive');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ekval))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ekval)/var(val(maxremove+48:end)));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_val )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_val/var(val(maxremove+48:end)));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ekval)/var(val(maxremove+48:end)))*100)
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_val/var(val(maxremove+48:end)))*100 ) 

disp('Are the residual ACF and PACF normal distributed:');
checkIfNormal( acf(ekval(2:end), 50), 'residual ACF' );
checkIfNormal( pacf(ekval(2:end), 50), 'residual PACF' );

plotACFnPACF(ekval, 50, 'ACF & PACF for prediction');


%% Test data 1 

k = 1;

[F, G] = polydivision( foundModelB.C, foundModelB.A, k );
xhatk = filter(G, foundModelB.C, test1rad );

xhatk = xhatk(length(G):end);


yhattest1 = filter(Fhh,1,xhatk) + filter(Ghh,KC,test1rad(48+k:end)) + filter(Gy, KC,test1(48+k:end));

maxremove = max([length(Fhh), length(Ghh), length(Gy), length(KC) length(Fy), length(KB), length(C)]);
yhattest1 = yhattest1(maxremove:end);



ektest1 = test1(maxremove+47+k:end) - yhattest1;

testDataInd1 = N_model+3336-50:N_model+3503;

if k == 1
   [yNaiveTest1, var_naive_test1] = naivePred(airTemperature, testDataInd1, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest1, var_naive_test1] = naivePred(airTemperature, testDataInd1, k, 24-k); 
end 


figure
plot([test1(maxremove+47+k:end) yhattest1 yNaiveTest1(47+maxremove+k:end)]);
legend('Real data', 'Model', 'Naive');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ektest1))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ektest1)/var(test1(maxremove+47+k:end)));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test1 )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test1/var(test1(maxremove+47+k:end)));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ektest1)/var(test1(71:end)))*100) 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test1/var(test1(71:end)))*100 ) 

plotACFnPACF(ektest1, 50, 'ACF & PACF for prediction');

%% Test data 2 

test2 = airTemperature(N_model+33000-50:N_model+33167);
test2rad = rad(N_model+33000-50:N_model+33167);
k = 1;

[F, G] = polydivision( foundModelB.C, foundModelB.A, k );
xhatk = filter(G, foundModelB.C, test2rad );

xhatk = xhatk(length(G):end);


yhattest2 = filter(Fhh,1,xhatk) + filter(Ghh,KC,test2rad(48+k:end)) + filter(Gy, KC,test2(48+k:end));

maxremove = max([length(Fhh), length(Ghh), length(Gy), length(KC) length(Fy), length(KB), length(C)]);
yhattest2 = yhattest2(maxremove:end);



ektest2 = test2(maxremove+47+k:end) - yhattest2;

testDataInd2 = N_model+33000-50:N_model+33167;

if k == 1
   [yNaiveTest2, var_naive_test2] = naivePred(airTemperature, testDataInd2, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest2, var_naive_test2] = naivePred(airTemperature, testDataInd2, k, 24-k); 
end 


figure
plot([test2(maxremove+47+k:end) yhattest2 yNaiveTest2(47+maxremove+k:end)]);
legend('Real data', 'Model', 'Naive');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ektest2))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ektest2)/var(test2(maxremove+47+k:end)));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test2 )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test2/var(test2(maxremove+47+k:end)));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ektest2)/var(test2(71:end)))*100) 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test2/var(test2(71:end)))*100 ) 

plotACFnPACF(ektest2, 50, 'ACF & PACF for prediction');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Stand-alone predictor part B 
clear;
close all;

load 'projectData24.mat'
k = 1; 


N_model = 1344; 
airTemperature = data(:,[8]);
test1Ind = N_model:N_model+167;

rad = data(:,[6]);

yhatk = predCodeB_grp008(rad, airTemperature, test1Ind, k); 

airtemp = airTemperature(test1Ind);
pe = airtemp(1:length(yhatk)) - yhatk;

figure
hold on
plot(airtemp)
plot(yhatk)
hold off


checkIfWhite(pe);
plotPlotsWillisLagerstedt(pe);


