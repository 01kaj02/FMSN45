%% Project Part C 
% Kajsa Hansson Willis & Victoria Lagerstedt
% Fall 2024 

clear; clc;
close all;
%% Setting up the data 

N_model  = 1344;

load 'projectData24.mat'
airTemperature = data(:,[8]);
rad = data(:,[6]);
T = 3000; % Setting the modeling data at the right spot in time 
set_temp = airTemperature(T:N_model+T); 
set_rad = rad(T:N_model+T);

% The validation data set
test1rad = rad((N_model+T+1):(N_model+T+168)); 
test1temp = airTemperature((N_model+T+1):(N_model+T+168)); 

extraN   = 1000;                                
N        = length(rad);
noLags   = 40;

%% The Kalman filter of the input model 

y = rad;
k  = 1;    % Note this is the only place K can be changed since the input model has to be changed if the k is changed later                                      
p0 = 8;                                         
q0 = 9;


% Initialization 
% Coefficients for the ARMApolynomials in B (but skipping the zeroes) 
initialVector = [0.0528397490288375	-0.101196205995669	0.206840167376422	-0.439378863960735	-0.0528397490288375	0.101196205995669	-0.206840167376422	-0.560621136039265 0.819084877316341	0.551287933376244	0.594313277080926	0.417096943364277	0.291422787928789	0.207143001159529	0.153405795663104	0.111067306439079	0.0381049043925346];

A     = eye(p0+q0);
Rw    = 2;                                 
Re    = 0.00000001*eye(p0+q0);
Rx_t1 = 4*eye(p0+q0);
h_et  = zeros(N,1);                             
xt    = ones(p0+q0,N-k);                       
xt    = xt.*initialVector';                       
yhat  = zeros(N-k,1);                           
yhatK = zeros(1,N+k);
xStd  = zeros(p0+q0,N-k);                       
xStdk = zeros(p0+q0,N-k);                       


for t=49:N-49 
    x_t1 = A*xt(:,t-1); %xt|t-1                   
    C  = [ -y(t-1) -y(t-2) -y(t-3) -y(t-24) -y(t-25) -y(t-26) -y(t-27) -y(t-48) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8) h_et(t-9)]; % C|t-1    
    
    Ry = C*Rx_t1*C' + Rw;  %% Ryyt|t-1                      
    Kt = Rx_t1*C'/Ry;  % Kt|t-1                         
    yhat(t) = C*x_t1;   % yt|t-1                        
    h_et(t) = y(t)-yhat(t);   %h_et|t                  
    xt(:,t) = x_t1 + Kt*(h_et(t)); % xt|(xt|t-1 + ...)           

    Rx_t  = Rx_t1 - Kt*Ry*Kt';  % Rxxt|t                
    Rx_t1 = A*Rx_t*A' + Re; % Rxxt+1|t                     

    % K = 1
    Ck = [ -y(t) -y(t-1) -y(t-2) -y(t-23) -y(t-24) -y(t-25) -y(t-26) -y(t-47) h_et(t) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8)];     
    yk = Ck*A*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
    
    Rx_k = Rx_t1;

    for k0=2:k
        if k == 2
            Ck = [ -yhatK(t-1+k0) -y(t-2+k0) -y(t-3+k0) -y(t-24+k0) -y(t-25+k0) -y(t-26+k0) -y(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ]; % C_{t+k|t}
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 4
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -y(t-3+k0) -y(t-24+k0) -y(t-25+k0) -y(t-26+k0) -y(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ]; % C_{t+k|t}
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re 
        elseif k < 25
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -y(t-24+k0) -y(t-25+k0) -y(t-26+k0) -y(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ]; % C_{t+k|t}
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 26
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-24+k0) -y(t-25+k0) -y(t-26+k0) -y(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ]; % C_{t+k|t}
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 27
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-24+k0) -yhatK(t-25+k0) -y(t-26+k0) -y(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ]; % C_{t+k|t}
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 28
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-24+k0) -yhatK(t-25+k0) -yhatK(t-26+k0) -y(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k < 49
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-24+k0) -yhatK(t-25+k0) -yhatK(t-26+k0) -yhatK(t-27+k0) -y(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        else
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-24+k0) -yhatK(t-25+k0) -yhatK(t-26+k0) -yhatK(t-27+k0) -yhatK(t-48+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) ];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        end
    end 

    yhatK(t+k) = yk;                      

    % Standard deviations 
    xStd(:,t) = sqrt(diag(Rx_t) );             
    xStdk(:,t) = sqrt(diag(Rx_k) );            
end

figure;
plot(yhatK(300:end));

bParams = [0.05284 -0.1012 0.2068 0.5606 0.8191 0.5513 0.5943 0.4171 0.2914 0.2071 0.1534 0.1111 0.0381];

params = xt(:,T:N_model+T);
std = xStd(:,T:N_model+T);

%Used in the report:
valparams = xt(:,N_model+T:N_model+T+335);
valstd = xStd(:,N_model+T:N_model+T+335);

figure
plotWithConf(1:1345, params', std', bParams);
axis([25-1 1345 -1 0.9])
title(sprintf('Estimated parameters for input, with Re = %7.6f and Rw = %4.3f', Re(1,1), Rw(1,1)))
xlabel('Time')
fprintf('The final values of the Kalman estimated parameters are:\n')
for k0=1:length(bParams)
    fprintf('  Value estimated in part B: %5.2f, estimated value: %5.2f (+/- %5.4f).\n', bParams(k0), xt(k0,1322), xStd(k0,1322) )
end
% Notice that they are quite different. 

%%  Evaluating the Kalman filter for the modeling data 

yhat2 = yhatK(T:N_model+T); 

figure
plot( [set_rad yhat2'] )
title('One-step prediction of input using the Kalman filter')
xlabel('Time')
legend('Realisation', 'Kalman estimate', 'Location','SW')
pe_mi = set_rad-yhat2';                   
plotACFnPACF(pe_mi, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n')
checkIfWhite(pe_mi);
checkIfNormal(acf(pe_mi,noLags),'ACF');

% It is redefined as input going into the air temperature Kalman filter 
xhatk = yhatK;

%% Testing input validation data

radval50 = rad((N_model+T+1-50):(N_model+T+168)); 

% With the naive predictor 
testDataInd = 51:168+50;
if k == 1
    [yNaiveTest, var_naive_] = naivePred(radval50, testDataInd, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest, var_naive_] = naivePred(radval50, testDataInd, k, 24-k); 
end 

res = test1rad - yhatK(T+N_model:T+N_model+167)';

figure
plot([test1rad yhatK(T+N_model:T+N_model+167)']);
hold on
plot(yNaiveTest);
hold off
title('One-step prediction of input using the Kalman filter');
xlabel('Time');
legend('Realisation', 'Kalman estimate', 'Naive', 'Location','SW');
pe_vi = test1rad-yhatK(T+N_model:T+N_model+167)';             
plotACFnPACF(pe_vi, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n');
checkIfWhite(pe_vi);
checkIfNormal(acf(pe_vi,noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(test1rad));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(res));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(res)/var(test1rad));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_/var(test1rad));

%% Testing input test data 1 

radtest50 = rad(N_model+T+168+1-50:N_model+T+168+168);

% With the naive predictor 
testDataInd = 51:168+50;
if k == 1
    [yNaiveTest, var_naive_] = naivePred(radtest50, testDataInd, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest, var_naive_] = naivePred(radtest50, testDataInd, k, 24-k); 
end 

radtest = radtest50(51:end);

res = radtest - yhatK(N_model+T+168+1:N_model+T+168+168)';

figure
plot([radtest yhatK(N_model+T+168+1:N_model+T+168+168)']);
hold on
plot(yNaiveTest);
hold off
title('One-step prediction of input using the Kalman filter');
xlabel('Time');
legend('Realisation', 'Kalman estimate', 'Naive', 'Location','SW');
pe_vi = radtest-yhatK(N_model+T+168+1:N_model+T+168+168)';             
plotACFnPACF(pe_vi, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n');
checkIfWhite(pe_vi);
checkIfNormal(acf(pe_vi,noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(radtest));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(res));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(res)/var(radtest));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_/var(radtest));


%% Testing input test data 2

% Randomly selected week of test data; the same as in A and B. 
radtest250 = rad(N_model+33000-50:N_model+33167);

% With the naive predictor 
testDataInd = 51:168+50;
if k == 1
    [yNaiveTest, var_naive_] = naivePred(radtest250, testDataInd, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest, var_naive_] = naivePred(radtest250, testDataInd, k, 24-k); 
end 

radtest2 = radtest250(51:end);

res = radtest2 - yhatK(N_model+33000:N_model+33167)';

figure
plot([radtest2 yhatK(N_model+33000:N_model+33167)']);
hold on
plot(yNaiveTest);
hold off
title('One-step prediction of input using the Kalman filter');
xlabel('Time');
legend('Realisation', 'Kalman estimate', 'Naive', 'Location','SW');
pe_vi = radtest2-yhatK(N_model+33000:N_model+33167)';             
plotACFnPACF(pe_vi, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n');
checkIfWhite(pe_vi);
checkIfNormal(acf(pe_vi,noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(radtest2));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(res));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(res)/var(radtest2));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_/var(radtest2));
%% Setting up the output model 

foundModelD = [1.0000   -1.7993    0.3148    0.6121    0.9218   -1.5894    0.5402];

foundModelF = [1];

foundModelB = [0.0068    0.0046    0.0019    0.0010];

foundModelC = [1.0000   -0.6167   -0.5515   -0.0533    0.9099   -0.2689    0.0429   -0.0180  -0.2438    0.1044   -0.0110    0.0205   -0.0774    0.0119    0.0351   -0.0013 0.0038   -0.2115    0.1116    0.0620    0.0550   -0.1360    0.0911   -0.0019];

KA = conv( foundModelD, foundModelF );
KB = conv( foundModelD, foundModelB );
KC = conv( foundModelF, foundModelC );

noPar   = 39;                            
xt      = zeros(noPar,N);               
xt(:,2) = [ KA(2) KA(3) KA(4) KA(5) KA(6) KA(7) KB(1) KB(2) KB(3) KB(4) KB(5) KB(6) KB(7) KB(8) KB(9) KB(10) KC(2) KC(3) KC(4) KC(5) KC(6) KC(7) KC(8) KC(9) KC(10) KC(11) KC(12) KC(13) KC(14) KC(15) KC(16) KC(17) KC(18) KC(19) KC(20) KC(21) KC(22) KC(23) KC(24) ];


%% The Kalman filter for the output model 

% Initialization 
x = rad;
y = airTemperature;

A     = eye(noPar);
Rw    = 1;                                
Re    = 1e-6*eye(noPar);                        
Rx_t1 = 1e-4*eye(noPar);                        
Rx_k  = Rx_t1;
h_et  = zeros(N,1); 
yhat  = zeros(N-k,1);
yhatK = zeros(1,N+k);                         
xStd_  = zeros(noPar,N);
xStdk_ = zeros(noPar,N);
startInd = 25;
%N-startInd

for t=startInd:N-startInd-25
    x_t1 = A*xt(:,t-1);                         
    C = [ -y(t-1) -y(t-2) -y(t-3) -y(t-4) -y(t-5) -y(t-6) x(t) x(t-1) x(t-2) x(t-3) x(t-4) x(t-5) x(t-6) x(t-7) x(t-8) x(t-9) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8) h_et(t-9) h_et(t-10) h_et(t-11) h_et(t-12) h_et(t-13) h_et(t-14) h_et(t-15) h_et(t-16) h_et(t-17) h_et(t-18) h_et(t-19) h_et(t-20) h_et(t-21) h_et(t-22) h_et(t-23)];
    yhat(t) = C*x_t1;

    Ry = C*Rx_t1*C' + Rw;                       
    Kt = Rx_t1*C'/Ry;                           
    h_et(t) = y(t)-yhat(t);                    
    xt(:,t) = x_t1 + Kt*( h_et(t) );            

    Rx_t  = Rx_t1 - Kt*Ry*Kt';                 
    Rx_t1 = A*Rx_t*A' + Re;                     

 
    %1-step prediction
    C1 = [ -y(t) -y(t-1) -y(t-2) -y(t-3) -y(t-4) -y(t-5) xhatk(t+1) x(t) x(t-1) x(t-2) x(t-3) x(t-4) x(t-5) x(t-6) x(t-7) x(t-8) h_et(t) h_et(t-1) h_et(t-2) h_et(t-3) h_et(t-4) h_et(t-5) h_et(t-6) h_et(t-7) h_et(t-8) h_et(t-9) h_et(t-10) h_et(t-11) h_et(t-12) h_et(t-13) h_et(t-14) h_et(t-15) h_et(t-16) h_et(t-17) h_et(t-18) h_et(t-19) h_et(t-20) h_et(t-21) h_et(t-22)];           
    yk = C1*xt(:,t); 
    Rx_k = Rx_t1;

    for k0=2:k
        if k == 2
            Ck = [ -yhatK(t-1+k0) -y(t-2+k0) -y(t-3+k0) -y(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) x(t-2+k0) x(t-3+k0) x(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 3
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -y(t-3+k0) -y(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) x(t-3+k0) x(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 4
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -y(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) x(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 5
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -y(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) x(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 6
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -y(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) x(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 7
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) x(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 8
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) xhatk(t-7+k0) x(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        elseif k == 9
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) xhatk(t-7+k0) xhatk(t-8+k0) x(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        else
            Ck = [ -yhatK(t-1+k0) -yhatK(t-2+k0) -yhatK(t-3+k0) -yhatK(t-4+k0) -yhatK(t-5+k0) -yhatK(t-6+k0) xhatk(t+k0) xhatk(t-1+k0) xhatk(t-2+k0) xhatk(t-3+k0) xhatk(t-4+k0) xhatk(t-5+k0) xhatk(t-6+k0) xhatk(t-7+k0) xhatk(t-8+k0) xhatk(t-9+k0) h_et(t-1+k0) h_et(t-2+k0) h_et(t-3+k0) h_et(t-4+k0) h_et(t-5+k0) h_et(t-6+k0) h_et(t-7+k0) h_et(t-8+k0) h_et(t-9+k0) h_et(t-10+k0) h_et(t-11+k0) h_et(t-12+k0) h_et(t-13+k0) h_et(t-14+k0) h_et(t-15+k0) h_et(t-16+k0) h_et(t-17+k0) h_et(t-18+k0) h_et(t-19+k0) h_et(t-20+k0) h_et(t-21+k0) h_et(t-22+k0) h_et(t-23+k0)];
            yk = Ck*A^k*xt(:,t);                    % \hat{y}_{t+k|t} = C_{t+k|t} A^k x_{t|t}
            Rx_k = A*Rx_k*A' + Re;                  % R_{t+k+1|t}^{x,x} = A R_{t+k|t}^{x,x} A^T + Re  
        end
    end 

    yhatK(t+k) = yk;
 
     % Standard deviations 
    xStd_(:,t) = sqrt(diag(Rx_t) );             
    xStdk_(:,t) = sqrt(diag(Rx_k) );   
end

figure
plot([set_temp yhatK(T:N_model+T)']);
legend('Real data', 'Prediction');

params = xt(:,T:N_model+T);
std = xStd_(:,T:N_model+T);

%Used in the report:
valparams = xt(:,N_model+T:N_model+T+335);
valstd = xStd_(:,N_model+T:N_model+T+335);

figure
plotWithConf(1:1345, params', std');
axis([25-1 1345 -1.5 1.5])
title(sprintf('Estimated parameters for input, with Re = %7.6f and Rw = %4.3f', Re(1,1), Rw(1,1)))
xlabel('Time')

%% Testing the output with the modeling data 

pre_set_temp = airTemperature(T-50:N_model+T); 

% With the naive predictor 
testDataIndmo = 1:length(pre_set_temp);
if k == 1
    [yNaiveTestm, var_naive_testm] = naivePred(pre_set_temp, testDataIndmo, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTestm, var_naive_testm] = naivePred(pre_set_temp, testDataIndmo, k, 24-k); 
end 

yNaiveTestm = yNaiveTestm(51:end);

yhatmo = yhatK(T:N_model+T);

% Comparing the model, the data and the naive predictor
figure
plot([set_temp yhatmo']);
hold on
plot(yNaiveTestm);
hold off
title('One-step prediction of input using the Kalman filter')
xlabel('Time')
legend('Realisation', 'Kalman estimate', 'Naive predictor', 'Location','SW');
emo = set_temp-yhatmo';                 
plotACFnPACF(emo, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n')
checkIfWhite(emo);
checkIfNormal(acf(emo, noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(set_temp));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(emo));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(emo)/var(set_temp));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_testm);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_testm/var(set_temp));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(emo)/var(set_temp))*100); 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_testm/var(set_temp))*100 ); 

% Inte white noise men ser rätt så bra ut ändå typ (följer inte
% normalfördelning men titta acf och graf) 

%% Testing the output with the validation data

pre_test1temp = airTemperature((N_model+T+1-50):(N_model+T+168)); 


% With the naive predictor 
testDataIndmo = 1:length(pre_test1temp);
if k == 1
    [yNaiveTestv, var_naive_testv] = naivePred(pre_test1temp, testDataIndmo, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTestv, var_naive_testv] = naivePred(pre_test1temp, testDataIndmo, k, 24-k); 
end 

yNaiveTestv = yNaiveTestv(51:end);

yhatvo = yhatK(T+N_model+1:N_model+T+168);

% Comparing the model, the data and the naive predictor
figure
plot([test1temp yhatvo']);
hold on
plot(yNaiveTestv);
hold off
title('One-step prediction of input using the Kalman filter')
xlabel('Time')
legend('Realisation', 'Kalman estimate', 'Naive predictor', 'Location','SW');
evo = test1temp-yhatvo';                 
plotACFnPACF(evo, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n')
checkIfWhite(evo);
checkIfNormal(acf(evo, noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(test1temp));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(evo));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(evo)/var(test1temp));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_testv);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_testv/var(test1temp));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(evo)/var(test1temp))*100); 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_testv/var(test1temp))*100 ); 

%% Test data 1

% The week directly following the validation data 
test1 = airTemperature(N_model+T+168+1-50:N_model+T+168+168);


% With the naive predictor 
testDataInd1 = 1:length(test1);
if k == 1
    [yNaiveTest1, var_naive_test1] = naivePred(test1, testDataInd1, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest1, var_naive_test1] = naivePred(test1, testDataInd1, k, 24-k); 
end 

yNaiveTest1 = yNaiveTest1(51:end);

t1 = test1(51:end);
yhat1 = yhatK(N_model+T+168+1:N_model+T+168+168);

% Comparing the model, the data and the naive predictor
figure
plot([t1 yhat1']);
hold on
plot(yNaiveTest1);
hold off
title('One-step prediction of input using the Kalman filter')
xlabel('Time')
legend('Realisation', 'Kalman estimate', 'Naive predictor', 'Location','SW');
e1 = t1-yhat1';                 
plotACFnPACF( e1, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n')
checkIfWhite(e1);
checkIfNormal(acf(e1, noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(t1));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(e1));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(e1)/var(t1));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test1);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test1/var(t1));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(e1)/var(t1))*100); 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test1/var(t1))*100 ); 

%% Test data 2

% Randomly selected week of test data; the same as in A and B. 
test2 = airTemperature(N_model+33000-50:N_model+33167);


% With the naive predictor 
testDataInd2 = 1:length(test2);
if k == 1
    [yNaiveTest2, var_naive_test2] = naivePred(test2, testDataInd2, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest2, var_naive_test2] = naivePred(test2, testDataInd2, k, 24-k); 
end 

yNaiveTest2 = yNaiveTest2(51:end);

t2 = test2(51:end);
yhat2 = yhatK(N_model+33000:N_model+33167);

% Comparing the model, the data and the naive predictor
figure
plot([t2 yhat2']);
hold on
plot(yNaiveTest2);
hold off
title('One-step prediction of input using the Kalman filter')
xlabel('Time')
legend('Realisation', 'Kalman estimate', 'Naive predictor', 'Location','SW');
e2 = t2-yhat2';                 
plotACFnPACF( e2, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n')
checkIfWhite(e2);
checkIfNormal(acf(e2, noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(t2));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(e2));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(e2)/var(t2));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test2);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test2/var(t2));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(e2)/var(t2))*100); 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test2/var(t2))*100 ); 

%% Random Test data 

% Randomly week of test data early in the period.
testn = airTemperature(N_model-50:N_model+167);


% With the naive predictor 
testDataIndn = 1:length(testn);
if k == 1
    [yNaiveTestn, var_naive_testn] = naivePred(testn, testDataIndn, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTestn, var_naive_testn] = naivePred(testn, testDataIndn, k, 24-k); 
end 

yNaiveTestn = yNaiveTestn(51:end);

tn = testn(51:end);
yhatn = yhatK(N_model:N_model+167);

% Comparing the model, the data and the naive predictor
figure
plot([tn yhatn']);
hold on
plot(yNaiveTestn);
hold off
title('One-step prediction of input using the Kalman filter')
xlabel('Time')
legend('Realisation', 'Kalman estimate', 'Naive predictor', 'Location','SW');
en = tn-yhatn';                 
plotACFnPACF( en, noLags, 'One-step prediction using the Kalman filter');
fprintf('Examining the one-step residual.\n')
checkIfWhite(en);
checkIfNormal(acf(en, noLags),'ACF');

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(tn));
fprintf('  The variance of the prediction residual is       %5.2f\n', var(en));
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(en)/var(tn));
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_testn);
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_testn/var(tn));

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(en)/var(tn))*100); 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_testn/var(tn))*100 ); 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Stand-alone predictor part C
clear;
close all;

load 'projectData24.mat'
k = 1; 
T = 3000;

N_model = 1344; 
airTemperature = data(:,[8]);
netRadiation = data(:,[6]);
%test1Ind = T+N_model:T+N_model+167;
test1Ind = N_model-50:N_model+167;

yhatk = predCodeC_grp008(netRadiation, airTemperature, test1Ind, k); 

figure;
hold on
plot(yhatk);
plot(airTemperature(test1Ind));
hold off

airtemp = airTemperature(test1Ind);
pe = airtemp(1:length(yhatk)) - yhatk; 

checkIfWhite(pe) % ska vara MA(k-1)
plotPlotsWillisLagerstedt(pe) 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
