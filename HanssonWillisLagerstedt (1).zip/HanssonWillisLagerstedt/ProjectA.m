%% Project Part A
% Kajsa Hansson Willis & Victoria Lagerstedt
% Fall 2024 

clear; clc;
close all;
%% Plotting the temperature data 

load 'projectData24.mat'
airTemperature = data(:,[8]);
figure
plot(airTemperature);
title('Air temperature');

maxOrd = 50;
N = length(airTemperature);
N_model = 1344; % 8 weeks of data 

figure
bcNormPlot(airTemperature,1)

disp('Normal distribution:');
checkIfNormal(airTemperature, 'data');
checkIfNormal(acf(airTemperature(2:end), 50), 'ACF');
checkIfNormal(pacf(airTemperature(2:end), 50), 'PACF');

%% Estimating a model on choosen model data

% Creating and viewing the modeling data
T = 3000; % Finding good point in time to use as modelling data 
set_temp = airTemperature(T:N_model+T); 
plotPlotsWillisLagerstedt(set_temp);

% Examining means and outliers in the modeling data 
testMean(set_temp); % Gives 1
min (set_temp);
max (set_temp);

% Creating an ARMA-model 
foundModel = estimateARMA(set_temp, [1 1 1 0 1 1], [1 1 1 1 1 0 0 1 1], 'Estimate ARMA', 30);

% The second and seventh C-parameter are insignificant according to confidence interval but
% removing it made it not white any more.

present(foundModel);

% Extracting the residuals and looking at their properties 
ex = resid(foundModel, set_temp);
plotPlotsWillisLagerstedt(ex);

disp('Is residual white:');
checkIfWhite(ex); 
disp('Variance of residual from model:');
var(ex); 
disp('Normalized variance of the residual from model:');
var(ex)/var(set_temp);

% Checking if there is pole-zero cancellation 
figure
pzplot(foundModel);

A_poly = foundModel.A;
C_poly = foundModel.C;

%% Check if the ACF and PACF are normal

ey = filter( foundModel.A, foundModel.C, set_temp );  
ey = ey(length(foundModel.A):end );

[acfEst, pacfEst] = plotACFnPACF( ey, 25, 'Project' );
disp('Are ACF and PACF normal distributed:');
checkIfNormal( acfEst(2:end), 'ACF' , 'D');
checkIfNormal( pacfEst(2:end), 'PACF' , 'D');

% They are normally distributed 

%% Create prediction with lag for the validation data  

% The validation data and 50 points prior to counter lost samples in the
% beginning after filtering 
val = airTemperature(N_model+T-50:N_model+T+335); % This data set begins before the valIndex so data samples do not have to be removed

% The ARMA model polynomials 
A = [1 -2.9526 2.6310 0 -1.0407 0.3623];
C = [1 -1.5560 -0.0492 0.8044 -0.1043 0 0 -0.0196 -0.0466];

k = 1;

% The prediction 
[~, Gk] = polydivision(C, A, k);

yhat_k = filter(Gk, C, airTemperature);

yhat_k = yhat_k(N_model+T-50:N_model+T+335);

% The residual 
ek = val(51:(end)) - yhat_k(51:end);

plotPlotsWillisLagerstedt(ek);

checkIfWhite(ek);

% With the naive predictor
testDataInd = 1:50+336;
if k == 1
    [yNaive, var_naive] = naivePred(val, testDataInd, 1);
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaive, var_naive] = naivePred(val, testDataInd, k, 24-k); 
end 
yNaive = yNaive(51:end);

figure; 
hold on
plot(val(51:end)); 
plot(yhat_k(51:end));
plot(yNaive);
legend('y','yhat', 'Naive');
hold off

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(val(51:end)))
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ek))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ek)/var(val(51:end)))

fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive/var(val(51:end)))

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ek)/var(val))*100) 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive/var(val(testDataInd)))*100 ) 


%% Check with testdata 1

% The first test data set and 50 points prior to counter lost samples in the
% beginning after filtering 
test1 = airTemperature(N_model+T+336-50:N_model+T+503);

A = [1 -2.9526 2.6310 0 -1.0407 0.3623];
C = [1 -1.5560 -0.0492 0.8044 -0.1043 0 0 -0.0196 -0.0466];
k = 18;

[~, Gk] = polydivision(C, A, k);

yhat_k_test1 = filter( Gk, C, airTemperature);
yhat_k_test1 = yhat_k_test1(N_model+T+336:N_model+T+503);

ek_test1 = test1(51:(end)) - yhat_k_test1;

figure 
subplot (211)
title('ACF')
a = acf(ek_test1, 50, 0.05, 1); 
subplot (212)
p = pacf(ek_test1, 50, 0.05, 1);
title('PACF')

disp('Are the ACF and PACF normally distributed:');
checkIfNormal(a, 'ACF');
checkIfNormal(p, 'PACF');

checkIfWhite(ek_test1);

% With the naive predictor
 testDataInd1 = 1:168+50;
if k == 1
    [yNaiveTest1, var_naive_test1] = naivePred(test1, testDataInd1, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest1, var_naive_test1] = naivePred(test1, testDataInd1, k, 24-k); 
end 
yNaiveTest1 = yNaiveTest1(51:end);

figure; 
hold on
plot(test1(51:end)); 
plot(yhat_k_test1);
plot(yNaiveTest1);
legend('y','yhat', 'Naive')
hold off

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(test1(51:end)))
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ek_test1))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ek_test1)/var(test1(51:end)))
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test1 )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test1/var(test1(51:end)))

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ek_test1)/var(test1))*100) 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test1/var(test1(testDataInd1)))*100 ) 

%% Check with testdata 2


set = N_model+33000:N_model+33167;
%set = N_model+57000:N_model+57167;
%set = N_model+35000:N_model+35167;
%set = N_model+20000:N_model+20167;

test2 = airTemperature(set);


A = [1 -2.9526 2.6310 0 -1.0407 0.3623];
C = [1 -1.5560 -0.0492 0.8044 -0.1043 0 0 -0.0196 -0.0466];
k = 18;

[Fk, Gk] = polydivision(C, A, k);

yhat_k_test2 = filter(Gk, C, airTemperature);
yhat_k_test2 = yhat_k_test2(set);

ek_test2 = test2 - yhat_k_test2;

figure 
subplot (211)
title('ACF')
a = acf(ek_test1, 50, 0.05, 1); 
subplot (212)
p = pacf(ek_test1, 50, 0.05, 1);
title('PACF')
checkIfWhite(ek_test2);

disp('Are the ACF and PACF normally distributed:');
checkIfNormal(a, 'ACF');
checkIfNormal(p, 'PACF');

% With the naive predictor:
testDataInd2 = 1:168;
if k == 1
    [yNaiveTest2, var_naive_test2] = naivePred(test2, testDataInd2, 1); 
else % If the prediction is more than one step ahead we want to use the time 24 hours before the time to be predicted, following the daily cycle 
    [yNaiveTest2, var_naive_test2] = naivePred(test2, testDataInd2, k, 24-k); 
end 
yNaiveTest2 = yNaiveTest2;

figure; 
hold on
plot(test2); 
plot(yhat_k_test2);
plot(yNaiveTest2);
legend('y','yhat', 'Naive')
hold off

fprintf('Prediction the signal %i-steps ahead.\n', k)
fprintf('  The variance of the data set is       %5.2f\n', var(test2))
fprintf('  The variance of the prediction residual is       %5.2f\n', var(ek_test2))
fprintf('  The normalized variance of the prediction residual is       %5.2f\n', var(ek_test2)/var(test2))
fprintf('  The variance of the naive prediction residual is %5.2f\n', var_naive_test2 )
fprintf('  The normalized variance of the naive prediction residual is %5.2f\n', var_naive_test2/var(test2))

fprintf('  Amount of signal that was predicted is       %5.2f%%\n', (1-var(ek_test2)/var(test2))*100) 
fprintf('  Amount predicted by the naive is             %5.2f%%\n', (1-var_naive_test2/var(test2(testDataInd2)))*100 ) 

%% Stand-alone predictor for part A 

%clear;
%close all;

load 'projectData24.mat'
airTemperature = data(:,[8]);

k = 1; 

% Determine the modeling data period 
N_model = 1344; 

% Choose the week (or period) to be predicted
test1Ind = N_model:N_model+167;  

yhatk = predCodeA_grp008([], airTemperature, test1Ind, k); 


% Test how well the stand-alone predictor works 
airtemp = airTemperature(test1Ind);
pe = airtemp - yhatk;

% This is expected be white noise for k = 1, otherwise it is does not have
% to be 
checkIfWhite(pe);

% This should be MA(k-1) 
plotPlotsWillisLagerstedt(pe);

disp('Are the ACF and PACF normally distributed:');
checkIfNormal(acf(pe(2:end), 50), 'ACF');
checkIfNormal(pacf(pe(2:end), 50), 'PACF');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
